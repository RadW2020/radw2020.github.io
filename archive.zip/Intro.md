---
layout: page
title: Presentación
---

Mi interés es hacer de este blog una especie de diario sobre como avanzo en el aprendizaje de las nuevas tecnologías.


### Presentación
Actualmente estoy estudiando Grado Superior en Desarrollo de Aplicaciones Multiplataforma, y el Grado Universitario Tecnologías de la Información por la UNED. Durante el desarrollo de mis ejercicios e investigaciones personales me encuentro con mucho material interesante que deseo compartir con compañeros y amigos.

Mi lista de intereses es muy variada, pero os propongo una lista inicial reducida para orientaros un poco sobre lo que espero desarrollar:

* Java
* Android
* JSF, J2EE
* Lenguajes de Marcado: HTML, XML
* Ruby + Ruby On Rails
* MySQL, Oracle SQL, PostgreSQL
* Hadoop, Spark
* Y mucho más ...

`System.out.println("Hola :D");`

[https://github.com/RadW2020](https://github.com/RadW2020)

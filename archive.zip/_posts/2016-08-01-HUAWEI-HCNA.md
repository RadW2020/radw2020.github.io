---
layout: post
title: HUAWEI-HCNA
---
<a href="https://blogs.uned.es/catedrahuawei/"><img src="https://blogs.uned.es/catedrahuawei/wp-content/uploads/sites/11/2015/12/fondo-banner.jpg" align="top" height="70" ></a>

Otro curso de la UNED que hice con anterioridad fue fruto de la colaboración de esta universidad
con HUAWEI.
[Enlace a Noticia](http://portal.uned.es/portal/page?_pageid=93,52836153&_dad=portal&_schema=PORTAL).

Esta empresa china está apostando fuerte por la educación y poniendo
en valor las certificaciones que acreditan los conocimientos
suficientes para operar su hardware.

<a href="http://www.huaweieducacion.com/"><img src="https://blogs.uned.es/catedrahuawei/wp-content/uploads/sites/11/2016/02/huawei-educacion-810x416.jpg" align="top" height="190" ></a>

Este hardware tiene un elevado nivel de desarrollo técnico, y trata de hacer
uso de las técnicas mas modernas para la gestión y aprovechamiento de
los recursos que proporcionan sus productos. Como por ejemplo los servidores [OceanStor 9000.](https://www.youtube.com/watch?v=HAGELUHssoQ)

<a href="url"><img src="http://image.slidesharecdn.com/huawei-131217172258-phpapp01/95/huawei-hpc-solutions-13-638.jpg?cb=1387358676" align="top" height="190" ></a>

El curso se llama **Cátedra Uned-Huawei de Cloud Computing y Big Data** y está destinado preparar la certificiación [HCNA-BCCP ](http://support.huawei.com/learning/news!toNewsInfo?newsId=Node1000007643&lang=en) (Huawei Certified Network Associate-Building Cloud Computing Platform),


A los 10 alumnos con mejor aprovechamiento del curso (entre los que por suerte me encuentro) se les ha asignado una beca para realizar el examen oficial de manera gratuita.

Los tres alumnos que obtengan mejores puntuaciones podrán realizar prácticas remuneradas durante seis meses en Huawei Madrid.

He realizado un resumen de la materia en Markdown, que este lenguaje me tiene ahora enganchado :) [Resumen](https://github.com/RadW2020/Huawei-HCNA-Cloud-Repo/blob/master/Readme.md)

Gracias y un saludo
